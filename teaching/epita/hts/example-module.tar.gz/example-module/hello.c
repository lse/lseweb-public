#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/printk.h>

static int __init hello_init(void)
{
	pr_info("%s: module loaded\n", THIS_MODULE->name);

	return 0;
}

static void __exit hello_exit(void)
{
	pr_info("%s: module unloaded\n", THIS_MODULE->name);
}

module_init(hello_init);
module_exit(hello_exit);

MODULE_AUTHOR("Gabriel Laskar <gabriel@lse.epita.fr>");
MODULE_DESCRIPTION("Sample hello world module");
MODULE_LICENSE("GPL");
