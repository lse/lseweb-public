# LRE sys-secu

## Authors

Alexandre Fresnais <alexandre.fresnais@epita.fr>
Antoine Jouan <antoine.jouan@epita.fr>
Alex Levigoureux <alex.levigoureux@epita.fr>

## Introduction

You will be presented with 4 CTF-like challenges.
The following instructions are fundamental:
 * Challenges are independent, you may approach them in any order you want.
 * There is only one flag for each challenge (except for *FSB files* where there is none).
 * Flags are in the format `flag{...}`
 * We **do not care** about you getting the flag. We are interested in your approach, what you have tried and what you understood from the challenges.
 * You are invited to write about the challenges you did not finish.
 * The report must be written in formal English and its quality is a part of the grade.

`Deadline 22/12/2022`

## Submission

You must submit your files on git.

```sh
git clone login@git.cri.epita.fr:p/lse/my_kremlin-login
```

Please include a README to explain your submission tree.

You are invited to include any tool or script **you** may have written to solve your challenges. Anything you did not write yourself in your directory will be considered as cheating. Usage of public tools is allowed and encouraged and should be linked in your report.

## Report writing

Your report should contain a section for each challenge you attempted.

You may propose multiple solutions to a challenge, but you are encouraged to solve every challenges first.

Again, flags are not the point of this subject, but you are expected to give the ones you found at the end of your solutions.

Do not wait until the last minute to write your report.

## my_kremlin

Kremlin (Russia) has declared cyberwar on Le Kremlin-Bicêtre (France). Our team is on the ground but your help would be appreciated !

Beware, don't underestimate the enemy ! Executing any given binary on your host may not be the best idea...

### Target (Easy)

Our team has successfully intercepted a file. It seems to be an ELF binary protecting a crucial information.

Find the password unlocking the message.

### Matrix (Medium)

Our sources told us that the FSB did not appreciate you cracking the password of their message vault. It seems that they hired mathematicians to create a new protection.
Please, break it again.

Find the flag protecting the message.

### Broken ELF (Hard)

Our team extracted parts of a binary from an intercepted communication. They tried their best to assemble all those parts to reconstruct a binary but there are some parts which are still not recovered. On their first analysis, they saw that the binary is used to check credentials. Now, you have to find all the inputs that unlock the binary. You will have to write a program that find all of them. Your program should run under 5 minutes.

#### Tips

Each input match `flag{xxxxxx}` where 6 is the maximum number of characters. The flag consists of only lowercase letters and numbers.
### Crypt (Medium)

Our undercover agent in some Russian secret service found a software used to encrypt messages. You need to find a way to exploit this program to get a shell !

You can use a very powerful library to help you to interact with the binary here : https://github.com/Gallopsled/pwntools

*No flag is expected here. Explain in your report how to exploit this program to obtain a shell. You are encouraged to include your script(s) in your submission.*

### Hospital (Hard)

Bicêtre Hospital has been attacked! We did not expect the enemy to be this evil.

Hopefully, we have successfully cleaned all computers running the malware. Our agents tried to analyse it. They found that given the correct input, the malware gave the enemy a shell on the Hospital's computers.

We could use the malware against its creators but we would need to know its expected input.

Find the input giving a shell.

### 31744 (Hard)

We extracted this file from the hard disk of the laptop of an enemy. It does not seem to be an ELF or any other type of executable. Our experts could not find its purpose.
Maybe it's a hoax to make us lose precious time.

Can you still take a look ? Maybe we are missing something.

### FSB files (Hard)

Our undercover agent in FSB organization exfiltrated a software used to create records on russian dissenters. If we manage to exploit this program, we could penetrate into FSB's computer system. Your job is to find vulnerabilities in this program and exploit them. It will be finished when you can get a local shell by "hacking" the program.

The version of your libc must be higher or equal to 2.27 (it should be the case on any modern linux).

You can use a very powerful library to help you to interact with the binary here : https://github.com/Gallopsled/pwntools

*No flag is expected here. Explain in your report how to exploit this program to obtain a shell. You are encouraged to include your script(s) in your submission.*
