void useless()
{
}
