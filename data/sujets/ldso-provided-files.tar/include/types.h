#ifndef TYPES_H
#define TYPES_H

typedef unsigned long u64;
typedef unsigned int u32;

typedef long i64;
typedef int i32;

#endif /* !TYPES_H */
