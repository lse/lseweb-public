#ifndef CTYPE_H
#define CTYPE_H

static inline int isdigit(int c)
{
	return c >= '0' && c <= '9';
}

#endif /* !CTYPE_H */
