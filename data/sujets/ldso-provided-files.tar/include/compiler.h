#ifndef COMPILER_H
#define COMPILER_H

#define array_size(N)	(sizeof(N) / sizeof(*N))

#endif /* !COMPILER_H */
